// src/utils/dateFormatter.js
 
export const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
   
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
   
  export const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
   
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
   
  export const formatRelativeTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
   
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
   
    return formatDate(dateString);
  };
   
  export const getDatePeriod = (type = 'quarterly') => {
    const now = new Date();
    const year = now.getFullYear();
    const quarter = Math.floor(now.getMonth() / 3) + 1;
   
    if (type === 'quarterly') {
      return `Q${quarter}-${year}`;
    }
   
    return `Annual-${year}`;
  };
  // src/utils/dateFormatter.js
   
  export const getQuarterString = (dateString) => {
    if (!dateString) return 'Unknown';
    try {
      const date = new Date(dateString);
     
      // ✅ Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn('Invalid date:', dateString);
        return 'Unknown';
      }
     
      const year = date.getFullYear();
      const month = date.getMonth(); // Jan = 0, Dec = 11
      const quarter = Math.floor(month / 3) + 1;
      const quarterStr = `Q${quarter}-${year}`;
      console.log(`✅ Date: ${dateString} → ${quarterStr}`);
      return quarterStr;
    } catch (err) {
      console.error('Error parsing date:', dateString, err);
      return 'Unknown';
    }
  };
   
   
   
   